package com.sqlcompiler;
public enum TokenType {
SELECT, 
FROM,
 WHERE,
 IDENTIFIER,
 NUMBER,
 STRING,
 EQUAL,
 GREATER,
 LESS,
 GREATER_EQUAL,
 LESS_EQUAL,
 NOT_EQUAL,
 ASTERISK,
 COMMA,
 SEMICOLON,
 END_OF_FILE,
 INVALID
}
